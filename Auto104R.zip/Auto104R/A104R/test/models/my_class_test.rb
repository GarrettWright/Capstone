require "test_helper"

class MyClassTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
