require "application_system_test_case"

class MyClassesTest < ApplicationSystemTestCase
  setup do
    @my_class = my_classes(:one)
  end

  test "visiting the index" do
    visit my_classes_url
    assert_selector "h1", text: "My classes"
  end

  test "should create my class" do
    visit my_classes_url
    click_on "New my class"

    fill_in "Class name", with: @my_class.Class_Name
    fill_in "Credit hours", with: @my_class.credit_hours
    fill_in "Grade", with: @my_class.grade
    fill_in "Semester taken", with: @my_class.semester_taken
    fill_in "Year taken", with: @my_class.year_taken
    click_on "Create My class"

    assert_text "My class was successfully created"
    click_on "Back"
  end

  test "should update My class" do
    visit my_class_url(@my_class)
    click_on "Edit this my class", match: :first

    fill_in "Class name", with: @my_class.Class_Name
    fill_in "Credit hours", with: @my_class.credit_hours
    fill_in "Grade", with: @my_class.grade
    fill_in "Semester taken", with: @my_class.semester_taken
    fill_in "Year taken", with: @my_class.year_taken
    click_on "Update My class"

    assert_text "My class was successfully updated"
    click_on "Back"
  end

  test "should destroy My class" do
    visit my_class_url(@my_class)
    click_on "Destroy this my class", match: :first

    assert_text "My class was successfully destroyed"
  end
end
