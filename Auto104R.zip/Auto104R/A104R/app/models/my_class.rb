class MyClass < ApplicationRecord
end
