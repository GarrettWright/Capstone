module MyClassesHelper
end
