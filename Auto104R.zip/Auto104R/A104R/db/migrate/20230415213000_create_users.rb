class CreateUsers < ActiveRecord::Migration[7.0]
  def change
    create_table :users do |t|
      t.string :User_Name
      t.string :Major
      t.string :Email
      t.string :phone_number
      t.string :Advisor
      t.string :Advisor_email
      t.string :Advisor_phone
      t.string :others

      t.timestamps
    end
  end
end
