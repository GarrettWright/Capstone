class CreateCourses < ActiveRecord::Migration[7.0]
  def change
    create_table :courses do |t|
      t.string :CRN
      t.string :class_name
      t.string :prof_name
      t.string :credit_hours
      t.string :semester
      t.timestamps
    end
  end
end
