class CreateMyClasses < ActiveRecord::Migration[7.0]
  def change
    create_table :my_classes do |t|
      t.string :Class_Name
      t.string :credit_hours
      t.string :grade
      t.string :semester_taken
      t.string :year_taken

      t.timestamps
    end
  end
end
